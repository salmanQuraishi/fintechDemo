<div id="businessoverview" class="tab-pane <?php echo e(Route::currentRouteName() == 'business.overview' ? 'active' : ''); ?>">
  <div class="xl:grid gap-12 flex 2xl:flex-row flex-col-reverse">
    <div class="2xl:col-span-8 xl:col-span-7">
      <h3 class="text-2xl font-bold pb-5 text-bgray-900 dark:text-white dark:border-darkblack-400 border-b border-bgray-200">
        Business Overview
      </h3>
      <form class="space-y-6" method="post" action="<?php echo e(route('business.overviewrequest')); ?>">
        <?php echo csrf_field(); ?>

        <div class="grid gap-4">
          
          <div class="flex flex-col gap-2">
            <label for="businessType" class="text-sm text-bgray-500 dark:text-bgray-50 block mt-2.5 text-left">Business Type *</label>
            <select name="businessType" class="bg-bgray-50 dark:bg-darkblack-500 dark:text-white p-4 rounded-lg h-14 border-0 focus:border focus:border-success-300 focus:ring-0">
              <option value="">Select Business Type</option>
              <?php $__currentLoopData = $BusinessType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $BusinessTypes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($BusinessTypes->id); ?>" 
                  <?php if(isset($BusinessKyc) && $BusinessKyc->business_type_id == $BusinessTypes->id): ?> selected <?php endif; ?>>
                  <?php echo e($BusinessTypes->name); ?>

                </option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('businessType'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('businessType')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
          </div>

          <div class="flex flex-col gap-2">
            <label for="businessCategory" class="text-sm text-bgray-500 dark:text-bgray-50 block mb-2.5 text-left">Business Category *</label>
            <select name="businessCategory" id="businessCategory" class="bg-bgray-50 dark:bg-darkblack-500 dark:text-white p-4 rounded-lg h-14 border-0 focus:border focus:border-success-300 focus:ring-0">
              <option value="">Select Business Category</option>
              <?php $__currentLoopData = $BusinessCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $BusinessCategorys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($BusinessCategorys->id); ?>" 
                  <?php if(isset($BusinessKyc) && $BusinessKyc->business_category_id == $BusinessCategorys->id): ?> selected <?php endif; ?>>
                  <?php echo e($BusinessCategorys->name); ?>

                </option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('businessCategory'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('businessCategory')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
          </div>

          <div class="flex flex-col gap-2">
            <label for="subCategory" class="text-sm text-bgray-500 dark:text-bgray-50 block mb-2.5 text-left">Sub Category *</label>
            <select name="subCategory" id="subCategory" class="bg-bgray-50 dark:bg-darkblack-500 dark:text-white p-4 rounded-lg h-14 border-0 focus:border focus:border-success-300 focus:ring-0">
              <option value="">Select Business Sub Category</option>
            </select>
            <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('subCategory'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('subCategory')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
          </div>

          <div class="flex flex-col gap-2">
            <label for="businessDescription" class="text-sm text-bgray-500 dark:text-bgray-50 block mb-2.5 text-left">Business Description</label>
            <textarea name="businessDescription" class="w-full border border-bgray-300 rounded-lg py-3 px-4 h-36 focus:border focus:border-success-300 focus:ring-0 dark:text-white dark:bg-darkblack-600 dark:border-darkblack-400 resize-none"><?php echo e(old('businessDescription', isset($BusinessKyc) ? $BusinessKyc->business_description : '')); ?></textarea>
            <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('businessDescription'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('businessDescription')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
          </div>

          <div class="text-sm text-bgray-500 dark:text-bgray-50 dark:text-white">
            <label class="text-sm text-bgray-500 dark:text-bgray-50 block mb-2.5 text-left">How do you wish to accept payments</label>
            <label class="inline-flex items-center mr-6 cursor-pointer">
              <input type="radio" name="paymentStatus" value="Without website/app" class="peer" 
                <?php if(isset($BusinessKyc) && $BusinessKyc->payment_status == 'Without website/app'): ?> checked <?php endif; ?> />
              <span class="peer-checked:text-blue-600"> Without website/app</span>
            </label>
            <br>
            <label class="inline-flex items-center cursor-pointer">
              <input type="radio" name="paymentStatus" value="On my website/app" class="peer" 
                <?php if(isset($BusinessKyc) && $BusinessKyc->payment_status == 'On my website/app'): ?> checked <?php endif; ?> />
              <span class="peer-checked:text-blue-600"> On my website/app</span>
            </label>
            <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('paymentStatus'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('paymentStatus')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
          </div>

          <div class="flex justify-end">
            <button class="bg-success-300 hover:bg-success-400 text-white text-base font-medium rounded-lg py-3 px-6">
              Submit
            </button>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>
<?php $__env->startPush('scripts'); ?>
<script>
  $(document).ready(function () {

    $('#businessCategory').select2();
    $('#subCategory').select2();

    $('#businessCategory').on('change', function () {
      var businessCategoryId = $(this).val();

      if (businessCategoryId) {
        $.ajax({
        url: '<?php echo e(route('getBusinessSubCategory')); ?>',
        type: 'POST',
        data: {
          id: businessCategoryId,
          _token: '<?php echo e(csrf_token()); ?>'
        },
        success: function (response) {
          if (response.status == "success") {
          var $select = $('#subCategory');

          $select.empty();

          $select.append('<option value="">Select Business Sub Category</option>');

          response.data.forEach(function (item) {
            $select.append('<option value="' + item.id + '">' + item.name + '</option>');
          });

          $select.trigger('change');

          console.log(response.data);
          } else {
          console.error('Error: ' + response.message);
          }
        },
        error: function (xhr, status, error) {
          console.error('Error occurred: ' + error);
        }
        });
      } else {
        console.log('No state selected');
        $('#subCategory').empty().append('<option value="">Select Business Sub Category</option>');
      }
    });
    function loadBusiness(){
      var businessCategoryId = $("#businessCategory").val();
      var subCategoryId = <?php echo e(isset($BusinessKyc) ? $BusinessKyc->business_sub_category_id : 0); ?>;
      

      if (businessCategoryId) {
        $.ajax({
        url: '<?php echo e(route('getBusinessSubCategory')); ?>',
        type: 'POST',
        data: {
          id: businessCategoryId,
          _token: '<?php echo e(csrf_token()); ?>'
        },
        success: function (response) {
          if (response.status == "success") {
          var $select = $('#subCategory');

          $select.empty();

          $select.append('<option value="">Select Business Sub Category</option>');

          response.data.forEach(function (item) {
            $select.append('<option value="' + item.id + '">' + item.name + '</option>');
          });

          response.data.forEach(function (item) {
            let selected = (subCategoryId == item.id) ? "selected" : "";
            $select.append('<option ' + selected + ' value="' + item.id + '">' + item.name + '</option>');
          });


          $select.trigger('change');

          console.log(response.data);
          } else {
          console.error('Error: ' + response.message);
          }
        },
        error: function (xhr, status, error) {
          console.error('Error occurred: ' + error);
        }
        });
      } else {
        console.log('No state selected');
        $('#subCategory').empty().append('<option value="">Select Business Sub Category</option>');
      }
    }
    loadBusiness();

  });
</script>
<?php $__env->stopPush(); ?><?php /**PATH E:\Projects\fintech\resources\views/kyc/overview.blade.php ENDPATH**/ ?>