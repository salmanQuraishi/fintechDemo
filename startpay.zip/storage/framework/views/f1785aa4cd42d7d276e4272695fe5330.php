<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(!empty($settings->title) ? $settings->title : config('app.name')); ?></title> 
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>assets/css/output.css">
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>assets/css/style.css">
    <link rel="icon" type="image/png" href="<?php echo e(!empty($settings->light_icon) ? $settings->light_icon : "assets/images/logo/logo-short-white.png"); ?>">
  </head>
  <body>

    <?php echo e($slot); ?>


    <script src="<?php echo e(asset('/')); ?>assets/js/jquery-3.6.0.min.js"></script>

    <script src="<?php echo e(asset('/')); ?>assets/js/main.js"></script>
  </body>
</html>
<?php /**PATH E:\Projects\fintech\resources\views/layouts/guest.blade.php ENDPATH**/ ?>