<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b = $attributes; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section class="bg-white dark:bg-darkblack-500">
        <div class="flex flex-col lg:flex-row justify-between min-h-screen">
            <!-- Left -->
            <div class="lg:w-1/2 px-5 xl:pl-12 pt-10">
                    <header>
                        <a href="<?php echo e(route('dashboard')); ?>" class="">
                            <img src="<?php echo e(asset('/')); ?><?php echo e($settings->logo_dark); ?>" class="block dark:hidden"
                                alt="Logo">
                            <img src="<?php echo e(asset('/')); ?><?php echo e($settings->logo_light); ?>" class="hidden dark:block"
                                alt="Logo">
                        </a>
                    </header>      
  
                <div class="max-w-[460px] m-auto pt-24 pb-16">
                    <header class="mb-8">
                        <h2 class="text-bgray-900 dark:text-white text-4xl font-semibold font-poppins mb-2">
                            Verify OTP
                        </h2>
                    </header>
                    <form method="POST" action="<?php echo e(route('verify')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="mb-4">
                            <input type="text"
                                class="text-bgray-800 dark:text-white dark:bg-darkblack-500 dark:border-darkblack-400  text-base border border-bgray-300 h-14 w-full focus:border-success-300 focus:ring-0 rounded-lg px-4 py-3.5 placeholder:text-bgray-500 placeholder:text-base"
                                placeholder="Enter otp here" name="otp" maxlength="10"
                                oninput="this.value = this.value.replace(/[^0-9]/g, '')">
                            <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('otp'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('otp')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                                <input type="hidden" name="mobile" value="<?php echo e(session('mobile')); ?>">
                        </div>
                        <input type="submit" class="py-3.5 text-center text-white font-bold bg-success-300 hover:bg-success-400 transition-all rounded-lg w-full" value="verify otp">
                    </form>
  
  
                </div>
            </div>
            <!-- Right -->
            <div class="lg:w-1/2 lg:block hidden bg-[#F6FAFF] dark:bg-darkblack-600 p-20 relative">
                <ul>
                    <li class="absolute top-10 left-8">
                        <img src="<?php echo e(asset('/')); ?>assets/images/shapes/square.svg" alt="">
                    </li>
                    <li class="absolute right-12 top-14">
                        <img src="<?php echo e(asset('/')); ?>assets/images/shapes/vline.svg" alt="">
                    </li>
                    <li class="absolute bottom-7 left-8">
                        <img src="<?php echo e(asset('/')); ?>assets/images/shapes/dotted.svg" alt="">
                    </li>
                </ul>
                <div class="mb-10">
                    <img src="<?php echo e(asset('/')); ?>assets/images/illustration/signup.svg" alt="">
                </div>
                <div>
                    <div class="text-center max-w-lg px-1.5 m-auto">
                        <h3 class="text-bgray-900 dark:text-white font-semibold font-popins text-4xl mb-4">
                            Speady, Easy and Fast
                        </h3>
                        <p class="text-bgray-600 dark:text-darkblack-300 text-sm font-medium">
                            BankCo. help you set saving goals, earn cash back offers, Go to
                            disclaimer for more details and get paychecks up to two days
                            early. Get a
                            <span class="text-success-300 font-bold">$20</span> bonus when
                            you receive qualifying direct deposits
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>
   <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $attributes = $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?><?php /**PATH E:\Projects\fintech\resources\views/auth/otp.blade.php ENDPATH**/ ?>