<div id="userblinkedaccounts" class="tab-pane <?php echo e(Route::currentRouteName() == 'userblinkedaccounts' ? 'active' : ''); ?>">
    <div class="xl:grid gap-12 flex 2xl:flex-row flex-col-reverse">
      <div class="2xl:col-span-8 xl:col-span-7">
        <h3
          class="text-2xl font-bold pb-5 text-bgray-900 dark:text-white dark:border-darkblack-400 border-b border-bgray-200">
          Linked Accounts
        </h3>
        <div class="mt-4">

          <form action="<?php echo e(route('linkedAccount')); ?>" method="post" class="mb-4">
            <?php echo csrf_field(); ?>
            <div class="flex flex-col md:flex-row justify-between gap-5 md:gap-x-8 mb-4">
        
                <div class="w-full flex flex-col gap-2">
                  <label for="BankName" class="text-base text-bgray-600 dark:text-bgray-50 font-medium">Bank Name*</label>
                  <input type="text" id="BankName" name="BankName"
                    class="bg-bgray-50 dark:bg-darkblack-500 dark:text-white p-4 rounded-lg h-14 border-0 focus:border focus:border-success-300 focus:ring-0"
                    value="<?php echo e(old('BankName')); ?>">
                    <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->first('BankName')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('BankName'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                </div>

                <div class="w-full flex flex-col gap-2">
                  <label for="AccountNumber" class="text-base text-bgray-600 dark:text-bgray-50 font-medium">Account Number*</label>
                  <input type="text" id="AccountNumber" name="AccountNumber"
                    class="bg-bgray-50 dark:bg-darkblack-500 dark:text-white p-4 rounded-lg h-14 border-0 focus:border focus:border-success-300 focus:ring-0"
                    value="<?php echo e(old('AccountNumber')); ?>" oninput="this.value = this.value.replace(/[^0-9]/g, '')">
                    <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->first('AccountNumber')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('AccountNumber'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                </div>
        
              </div>
            <div class="flex flex-col md:flex-row justify-between gap-5 md:gap-x-8 mb-4">
        
                <div class="flex flex-col gap-2 w-full">
                  <label for="IFSC" class="text-base text-bgray-600 dark:text-bgray-50 font-medium">IFSC*</label>
                  <input type="text" id="IFSC" name="IFSC"
                    class="bg-bgray-50 dark:bg-darkblack-500 dark:text-white p-4 rounded-lg h-14 border-0 focus:border focus:border-success-300 focus:ring-0"
                    value="<?php echo e(old('IFSC')); ?>">
                    <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->first('IFSC')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('IFSC'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                </div>

                <div class="flex flex-col gap-2 w-full">
                  <label for="AccountType" class="text-base text-bgray-600 dark:text-bgray-50 font-medium">Account Type *</label>
                  <select name="AccountType" class="bg-bgray-50 dark:bg-darkblack-500 dark:text-white p-4 rounded-lg h-14 border-0 focus:border focus:border-success-300 focus:ring-0">
                      <option value="saving">Saving</option>
                      <option value="current">Current</option>
                  </select>                                                
                  <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('AccountType'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('AccountType')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                </div>

                <div class="flex flex-col gap-2 w-full">
                  <label for="Status" class="text-base text-bgray-600 dark:text-bgray-50 font-medium">Status *</label>
                  <select name="Status" class="bg-bgray-50 dark:bg-darkblack-500 dark:text-white p-4 rounded-lg h-14 border-0 focus:border focus:border-success-300 focus:ring-0">
                      <option value="active">Active</option>
                      <option value="inactive">Inactive</option>
                  </select>                                                
                  <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('Status'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('Status')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                </div>
        
              </div>
              <button class="bg-success-300 hover:bg-success-400 text-white font-semibold text-base py-4 flex justify-center items-center rounded-lg w-full mt-2">
                submit
              </button>

        </form>


          <div class="table-content w-full overflow-x-auto">
            <table class="w-full">
                <tr class="border-b border-bgray-300 dark:border-darkblack-400">
                    <td class="py-5 ">
                      <span class="text-base font-medium text-bgray-600 dark:text-bgray-50">
                        #</span>
                    </td>
                    <td class="py-5  xl:px-0">
                      <span class="text-base font-medium text-bgray-600 dark:text-bgray-50">Bank Name</span>
                    </td>
                    <td class="py-5  xl:px-0">
                      <span class="text-base font-medium text-bgray-600 dark:text-bgray-50">A/c</span>
                    </td>
                    <td class="py-5  xl:px-0">
                      <span class="text-base font-medium text-bgray-600 dark:text-bgray-50">IFSC</span>
                    </td>
                    <td class="py-5 ">
                      <span class="text-base font-medium text-bgray-600 dark:text-gray-50">
                          Type</span>
                    </td>
                    <td class="py-5 ">
                      <span class="text-base font-medium text-bgray-600 dark:text-gray-50">
                          Status</span>
                    </td>
                    <td class="py-5 ">
                      <span class="text-base font-medium text-bgray-600 dark:text-gray-50">
                        Action</span>
                    </td>
                </tr>
              <?php $__currentLoopData = $UserBankAccounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accountData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td class="py-5 ">
                    <p class="font-medium text-base text-bgray-900 dark:text-bgray-50"><?php echo e($loop->iteration); ?></p>
                  </td>
                  <td class="py-5 ">
                    <p class="font-medium text-base text-bgray-900 dark:text-bgray-50"><?php echo e($accountData->bank_name); ?></p>
                  </td>
                  <td class="py-5 ">
                    <p class="font-medium text-base text-bgray-900 dark:text-bgray-50"><?php echo e($accountData->account_no); ?></p>
                  </td>
                  <td class="py-5 ">
                    <p class="font-medium text-base text-bgray-900 dark:text-bgray-50"><?php echo e($accountData->ifsc); ?></p>
                  </td>
                  <td class="py-5 ">
                    <p class="font-medium text-base text-bgray-900 dark:text-bgray-50"><?php echo e($accountData->type); ?></p>
                  </td>
                  <td class="py-5 ">
                    <label class="rounded-md bg-[#FAEFEE] px-4 py-1.5 text-sm font-semibold leading-[22px]  dark:bg-darkblack-500 <?php echo e($accountData->status === 'active' ? 'text-success-400' : 'text-[#FF4747]'); ?>"><?php echo e($accountData->status); ?></label>
                  </td>
                  <td class="py-5">
                    <form action="<?php echo e(route('updateaccountStatus', $accountData->id)); ?>" method="POST">
                      <?php echo csrf_field(); ?>
                      <?php echo method_field('PUT'); ?>
                      <label class="switch">
                          <input type="checkbox" name="status"
                                 onchange="this.form.submit()"
                                 <?php echo e($accountData->status === 'active' ? 'checked' : ''); ?>>
                          <span class="slider"></span>
                      </label>
                    </form>
                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
          </div>
        </div>
      </div>
    </div>
</div>

<script>
    const checkboxes = document.querySelectorAll('input[type="checkbox"]');
    checkboxes.forEach(checkbox => {
      checkbox.addEventListener('change', function () {
      const day = this.id;
      document.getElementById(`${day}-start`).disabled = !this.checked;
      document.getElementById(`${day}-end`).disabled = !this.checked;
      });
    });
</script><?php /**PATH E:\Projects\fintech\resources\views/profile/userblinkedaccounts.blade.php ENDPATH**/ ?>